Section summary: transport

Evidence:
- score=0.246: [POL:sample_policy_p1] Policy T1 Sustainable Transport
Policy T1 requires developments to demonstrate car-lite outcomes and safeguard cycle parking in accordan
- score=0.111: [POL:sample_policy_2_p1] Policy T2 Cycle Parking
Policy T2 states strategic schemes must provide long stay cycle parking and minimise vehicular access.
- score=0.066: [APP:sample_app_p1] Transport Statement
The applicant states that the scheme delivers 100 cycle parking spaces and minimises car travel.
- score=0.066: [APP:sample_app_2_p1] Travel Plan Summary
The applicant states that modal shift targets will be achieved within five years with robust monitoring.

Constraints:
Use only retrieved evidence; do not invent citations.
Every paragraph must include at least one policy citation where applicable.